﻿import {
  loadData,
  loadDataFromArea,
  saveData,
  clearData,
  createBackupSnapshot,
  loadIconCache,
  saveIconCache,
  defaultData,
  getChromeApi,
} from "./storage.js";
import { getBingWallpaper } from "./bing-wallpaper.js";
import { resolveIcon, refreshAllIcons, retryFailedIconsIfDue, getFaviconCandidates, getSiteKey } from "./icons.js";

const $ = (id) => document.getElementById(id);
const qs = (sel, root = document) => root.querySelector(sel);
const qsa = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const elements = {
  background: $("background"),
  grid: $("grid"),
  emptyState: $("emptyState"),
  emptyHintToggle: $("emptyHintToggle"),
  main: document.querySelector(".main"),
  recentTab: $("recentTab"),
  groupTabs: $("groupTabs"),
  topSearch: $("topSearch"),
  topSearchWrap: $("topSearchWrap"),
  btnAdd: $("btnAdd"),
  btnBatchDelete: $("btnBatchDelete"),
  btnSelectAll: $("btnSelectAll"),
  btnOpenMode: $("btnOpenMode"),
  btnSettings: $("btnSettings"),
  btnSearch: $("btnSearch"),
  btnToggleSidebar: $("btnToggleSidebar"),
  btnAddGroup: $("btnAddGroup"),
  modalOverlay: $("modalOverlay"),
  modal: $("modal"),
  contextMenu: $("contextMenu"),
  toastContainer: $("toastContainer"),
  tooltip: $("tooltip"),
  folderOverlay: $("folderOverlay"),
  folderGrid: $("folderGrid"),
  folderTitle: $("folderTitle"),
  btnCloseFolder: $("btnCloseFolder"),
  btnFolderAdd: $("btnFolderAdd"),
  btnFolderBatchDelete: $("btnFolderBatchDelete"),
};

let data = null;
let activeGroupId = null;
let openFolderId = null;
let selectionMode = false;
let selectedIds = new Set();
let pendingDeletion = null;
let tooltipTimer = null;
let dragState = null;
let lastSelectedIndex = null;
let recentItems = [];
let draggingGroupId = null;
let boxSelecting = false;
let selectionBox = null;
let selectionStart = null;
let suppressBlankClick = false;
let isDraggingBox = false;
let settingsOpen = false;
let settingsSaving = false;
let renderSeq = 0;
const DEBUG_LOG_KEY = "homepage_debug_log";

const RECENT_GROUP_ID = "__recent__";
const RECENT_LIMIT = 24;

const densityMap = {
  compact: { gap: 10, size: 80, font: 12, icon: 32 },
  standard: { gap: 16, size: 96, font: 13, icon: 38 },
  spacious: { gap: 22, size: 112, font: 14, icon: 44 },
};

function debugLog(event, payload = {}) {
  const entry = { ts: Date.now(), event, payload };
  try {
    const raw = localStorage.getItem(DEBUG_LOG_KEY);
    const list = raw ? JSON.parse(raw) : [];
    list.unshift(entry);
    localStorage.setItem(DEBUG_LOG_KEY, JSON.stringify(list.slice(0, 200)));
  } catch (err) {
    console.warn("debugLog failed", err);
  }
  console.log("[debug]", entry);
}

function getRuntimeInfo() {
  const api = getChromeApi();
  return {
    runtimeId: api?.runtime?.id || "",
    href: window.location.href,
    origin: window.location.origin,
  };
}

function shouldDebugPersist() {
  try {
    return localStorage.getItem("homepage_debug_persist") === "1";
  } catch {
    return false;
  }
}

window.homepageDebugLog = () => {
  try {
    return JSON.parse(localStorage.getItem(DEBUG_LOG_KEY) || "[]");
  } catch {
    return [];
  }
};

window.homepageDebugEnv = async () => {
  const api = getChromeApi();
  const info = getRuntimeInfo();
  return new Promise((resolve) => {
    if (!api?.storage?.local?.getBytesInUse) return resolve(info);
    api.storage.local.getBytesInUse("homepage_data", (bytes) => {
      resolve({ ...info, bytes });
    });
  });
};

function applyDensity() {
  const d = densityMap[data.settings.gridDensity] || densityMap.standard;
  document.documentElement.style.setProperty("--grid-gap", `${d.gap}px`);
  document.documentElement.style.setProperty("--tile-size", `${d.size}px`);
  const baseFont = Number(data.settings.fontSize) || d.font;
  document.documentElement.style.setProperty("--tile-font", `${baseFont}px`);
  document.documentElement.style.setProperty("--base-font", `${baseFont}px`);
  document.documentElement.style.setProperty("--tile-icon", `${d.icon}px`);
}

function applyTheme() {
  const theme = data.settings.theme || "system";
  if (theme === "system") {
    const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    document.documentElement.setAttribute("data-theme", prefersDark ? "dark" : "light");
    return;
  }
  document.documentElement.setAttribute("data-theme", theme);
}

function applySidebarState() {
  document.body.classList.toggle("sidebar-collapsed", !!data.settings.sidebarCollapsed);
  if (elements.btnToggleSidebar) {
    elements.btnToggleSidebar.textContent = data.settings.sidebarCollapsed ? "展开" : "收起";
  }
}

function toast(message, actionLabel, action) {
  const el = document.createElement("div");
  el.className = "toast";
  el.innerHTML = `<span>${message}</span>`;
  if (actionLabel && action) {
    const btn = document.createElement("button");
    btn.textContent = actionLabel;
    btn.addEventListener("click", () => {
      action();
      el.remove();
    });
    el.appendChild(btn);
  }
  elements.toastContainer.appendChild(el);
  setTimeout(() => el.remove(), 5000);
}

function showTooltip(text, x, y) {
  if (!data.settings.tooltipEnabled) return;
  elements.tooltip.textContent = text;
  elements.tooltip.style.left = `${x + 12}px`;
  elements.tooltip.style.top = `${y + 12}px`;
  elements.tooltip.classList.remove("hidden");
}

function hideTooltip() {
  elements.tooltip.classList.add("hidden");
}

function normalizeUrl(input) {
  if (!input) return "";
  try {
    const url = new URL(input);
    return url.href;
  } catch (err) {
    const withScheme = `https://${input}`;
    try {
      const url = new URL(withScheme);
      return url.href;
    } catch (err2) {
      return "";
    }
  }
}

async function openUrl(url, mode) {
  const api = getChromeApi();
  const openMode = mode || data.settings.openMode;
  if (api?.tabs && (openMode === "new" || openMode === "background")) {
    api.tabs.create({ url, active: openMode !== "background" });
    return;
  }
  if (openMode === "new") {
    window.open(url, "_blank");
  } else if (openMode === "background") {
    window.open(url, "_blank", "noopener,noreferrer");
  } else {
    window.location.href = url;
  }
}

function setBackground(style) {
  if (!style) return;
  if (style.startsWith("data:") || style.startsWith("http")) {
    elements.background.style.backgroundImage = `url('${style}')`;
  } else {
    elements.background.style.backgroundImage = style;
  }
}

async function loadBackground() {
  const settings = data.settings;
  elements.background.classList.add("is-loading");

  if (settings.backgroundType === "bing") {
    const info = await getBingWallpaper();
    if (info.dataUrl) {
      setBackground(info.dataUrl);
      if (info.failed) toast("壁纸获取失败，已回退到缓存");
      else toast("已更新今日 Bing 壁纸");
    } else {
      elements.background.style.background = settings.backgroundColor;
      toast("壁纸获取失败，已使用默认背景");
    }
  } else if (settings.backgroundType === "color") {
    elements.background.style.backgroundImage = "none";
    elements.background.style.background = settings.backgroundColor;
  } else if (settings.backgroundType === "gradient") {
    setBackground(settings.backgroundGradient);
  } else if (settings.backgroundType === "custom") {
    setBackground(settings.backgroundCustom || settings.backgroundColor);
  }

  elements.background.classList.remove("is-loading");
}

function pushBackup() {
  if (!data.settings.maxBackups) return;
  const snapshot = createBackupSnapshot(data);
  data.backups.unshift(snapshot);
  if (data.settings.maxBackups > 0 && data.backups.length > data.settings.maxBackups) {
    data.backups = data.backups.slice(0, data.settings.maxBackups);
  }
}

async function persistData() {
  debugLog("persist_start", {
    useSync: data.settings.syncEnabled,
    groups: data.groups?.length || 0,
    nodes: Object.keys(data.nodes || {}).length,
    lastUpdated: data.lastUpdated || 0,
  });
  const useSync = data.settings.syncEnabled;
  const changed = dedupeData(data);
  let warning = null;
  let err = null;
  const err1 = await saveData(data, useSync);
  if (err1) {
    if (err1 === "sync_quota_exceeded" || err1.startsWith("local_trimmed_")) {
      warning = err1;
    } else {
      err = err1;
    }
  }
  if (useSync) {
    await saveData(data, false);
  }
  if (changed) {
    const err2 = await saveData(data, useSync);
    if (useSync) await saveData(data, false);
    if (err2) {
      if (err2 === "sync_quota_exceeded" || err2.startsWith("local_trimmed_")) {
        warning = err2;
      } else {
        err = err2;
      }
    }
    debugLog("persist_dedupe", { changed, err2 });
  }
  if (shouldDebugPersist()) {
    const verify = await loadDataFromArea(false);
    debugLog("persist_verify", {
      groups: verify.groups?.length || 0,
      nodes: Object.keys(verify.nodes || {}).length,
      lastUpdated: verify.lastUpdated || 0,
    });
  }
  debugLog("persist_done", { err1, changed, warning, err });
  return { ok: !err, warning, err };
}

function getActiveGroup() {
  return data.groups.find((g) => g.id === activeGroupId) || data.groups[0];
}

function getCurrentNodes() {
  if (activeGroupId === RECENT_GROUP_ID) return recentItems;
  const group = getActiveGroup();
  const nodeIds = openFolderId ? data.nodes[openFolderId]?.children || [] : group.nodes;
  return nodeIds.map((id) => data.nodes[id]).filter(Boolean);
}

function uniqueNodes(nodes) {
  const seenId = new Set();
  const out = [];
  for (const node of nodes) {
    if (!node?.id) continue;
    if (seenId.has(node.id)) continue;
    seenId.add(node.id);
    out.push(node);
  }
  return out;
}

function renderGroups() {
  elements.groupTabs.innerHTML = "";
  elements.recentTab.classList.toggle("active", activeGroupId === RECENT_GROUP_ID);
  data.groups
    .sort((a, b) => a.order - b.order)
    .forEach((group) => {
      const btn = document.createElement("button");
      btn.className = `group-tab draggable ${group.id === activeGroupId ? "active" : ""}`;
      btn.textContent = group.name;
      btn.draggable = true;
      btn.addEventListener("click", () => {
        activeGroupId = group.id;
        openFolderId = null;
        data.settings.lastActiveGroupId = activeGroupId;
        persistData();
        render();
      });
      btn.addEventListener("contextmenu", (e) => {
        e.preventDefault();
        openGroupContextMenu(e.clientX, e.clientY, group);
      });
      btn.addEventListener("dragstart", () => {
        draggingGroupId = group.id;
        btn.classList.add("dragging");
      });
      btn.addEventListener("dragend", () => {
        draggingGroupId = null;
        btn.classList.remove("dragging");
        qsa(".group-tab", elements.groupTabs).forEach((el) => el.classList.remove("drop-target"));
      });
      btn.addEventListener("dragover", (e) => {
        e.preventDefault();
        btn.classList.add("drop-target");
      });
      btn.addEventListener("dragleave", () => {
        btn.classList.remove("drop-target");
      });
      btn.addEventListener("drop", (e) => {
        e.preventDefault();
        btn.classList.remove("drop-target");
        if (!draggingGroupId || draggingGroupId === group.id) return;
        moveGroupBefore(draggingGroupId, group.id);
      });
      elements.groupTabs.appendChild(btn);
    });
}

async function renderGrid() {
  const seq = ++renderSeq;
  const grid = openFolderId ? elements.folderGrid : elements.grid;
  const nodes = uniqueNodes(getCurrentNodes());
  grid.innerHTML = "";

  const width = grid.getBoundingClientRect().width || grid.clientWidth || window.innerWidth;
  const density = densityMap[data.settings.gridDensity] || densityMap.standard;
  const tileSize = density.size || 96;
  const gap = density.gap || 16;
  const style = getComputedStyle(grid);
  const paddingX = (parseFloat(style.paddingLeft) || 0) + (parseFloat(style.paddingRight) || 0);
  const available = Math.max(0, width - paddingX);
  const maxColumns = Math.max(1, Math.floor((available + gap) / (tileSize + gap)));
  let columns = Math.max(1, maxColumns);
  if (data.settings.fixedLayout) {
    const desired = Math.max(1, data.settings.fixedCols || 8);
    columns = Math.min(desired, maxColumns);
  }
  grid.style.gridTemplateColumns = `repeat(${columns}, minmax(${tileSize}px, 1fr))`;

  for (const [idx, node] of nodes.entries()) {
    if (seq !== renderSeq) return;
    const tile = document.createElement("div");
    tile.className = "tile";
    tile.dataset.id = node.id;
    tile.dataset.index = idx;
    tile.draggable = true;
    tile.tabIndex = 0;

    const icon = document.createElement("div");
    icon.className = "tile-icon";
    const img = document.createElement("img");
    img.alt = node.title || node.url || "";
    const iconSrc = await resolveIcon(node, data.settings);
    img.src = iconSrc;
    if (node.url && data.settings.iconFetch && !iconSrc.startsWith("data:")) {
      const candidates = getFaviconCandidates(node.url);
      if (candidates.length) {
        let idx = Math.max(0, candidates.indexOf(iconSrc));
        img.onerror = () => {
          idx += 1;
          if (idx < candidates.length) img.src = candidates[idx];
        };
      }
    }
    if (seq !== renderSeq) return;
    icon.appendChild(img);

    const title = document.createElement("div");
    title.className = "tile-title";
    title.textContent = node.title || node.url || "未命名";

    tile.appendChild(icon);
    tile.appendChild(title);

    if (node.type === "folder") {
      const badge = document.createElement("div");
      badge.className = "tile-badge";
      badge.textContent = `${node.children?.length || 0}`;
      tile.appendChild(badge);
    }

    if (selectedIds.has(node.id)) {
      tile.classList.add("selected");
    }

    tile.addEventListener("click", (e) => {
      if (selectionMode) {
        toggleSelect(node.id, idx, e.shiftKey);
        return;
      }
      if (node.type === "folder") {
        openFolder(node.id);
      } else {
        const url = normalizeUrl(node.url);
        if (!url) {
          toast("URL 无效");
          return;
        }
        openUrl(url);
      }
    });

    tile.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      openContextMenu(e.clientX, e.clientY, node);
    });

    tile.addEventListener("mouseenter", (e) => {
      if (!data.settings.tooltipEnabled) return;
      clearTimeout(tooltipTimer);
      const text = node.type === "folder" ? `${node.title}（文件夹）` : `${node.title}\n${node.url}`;
      tooltipTimer = setTimeout(() => showTooltip(text, e.clientX, e.clientY), 200);
    });
    tile.addEventListener("mouseleave", () => {
      clearTimeout(tooltipTimer);
      hideTooltip();
    });

    tile.addEventListener("dragstart", (e) => {
      dragState = { id: node.id, fromFolder: openFolderId };
      e.dataTransfer.effectAllowed = "move";
    });
    tile.addEventListener("dragover", (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
    });
    tile.addEventListener("drop", (e) => {
      e.preventDefault();
      e.stopPropagation();
      handleDropOnTile(node.id);
    });

    grid.appendChild(tile);
  }

  updateEmptyState();
}

function updateEmptyState() {
  if (activeGroupId === RECENT_GROUP_ID) {
    elements.emptyState.classList.add("hidden");
    return;
  }
  const nodes = getCurrentNodes();
  if (nodes.length === 0 && !data.settings.emptyHintDisabled) {
    elements.emptyState.classList.remove("hidden");
  } else {
    elements.emptyState.classList.add("hidden");
  }
}

function openFolder(folderId) {
  openFolderId = folderId;
  elements.folderOverlay.classList.remove("hidden");
  elements.folderOverlay.setAttribute("aria-hidden", "false");
  elements.folderTitle.textContent = data.nodes[folderId]?.title || "文件夹";
  render();
}

function closeFolder() {
  openFolderId = null;
  elements.folderOverlay.classList.add("hidden");
  elements.folderOverlay.setAttribute("aria-hidden", "true");
  render();
}

function toggleSelect(id, index, range) {
  const nodes = getCurrentNodes();
  if (range && lastSelectedIndex !== null) {
    const start = Math.min(lastSelectedIndex, index);
    const end = Math.max(lastSelectedIndex, index);
    for (let i = start; i <= end; i++) {
      if (nodes[i]) selectedIds.add(nodes[i].id);
    }
  } else {
    if (selectedIds.has(id)) selectedIds.delete(id);
    else selectedIds.add(id);
    lastSelectedIndex = index;
  }
  if (lastSelectedIndex === null && typeof index === "number") {
    lastSelectedIndex = index;
  }
  render();
}

function clearSelection() {
  selectedIds.clear();
  selectionMode = false;
  lastSelectedIndex = null;
  if (selectionBox) {
    selectionBox.remove();
    selectionBox = null;
  }
}

function openContextMenu(x, y, node) {
  elements.contextMenu.innerHTML = "";
  const actions = [];
  if (activeGroupId === RECENT_GROUP_ID && node.type === "history") {
    actions.push({ label: "打开", fn: () => openUrl(normalizeUrl(node.url)) });
    actions.push({ label: "新标签打开", fn: () => openUrl(normalizeUrl(node.url), "new") });
    actions.push({ label: "添加到快捷", fn: () => addHistoryToShortcuts(node) });
  } else if (node.type !== "folder") {
    actions.push({ label: "打开", fn: () => openUrl(normalizeUrl(node.url)) });
    actions.push({ label: "新标签打开", fn: () => openUrl(normalizeUrl(node.url), "new") });
    actions.push({ label: "后台打开", fn: () => openUrl(normalizeUrl(node.url), "background") });
  } else {
    actions.push({ label: "打开文件夹", fn: () => openFolder(node.id) });
    actions.push({ label: "解散文件夹", fn: () => dissolveFolder(node.id) });
  }
  if (node.type !== "history") {
    actions.push({ label: "编辑", fn: () => openEditModal(node) });
    actions.push({ label: "删除", fn: () => deleteNodes([node.id]) });
  }

  for (const action of actions) {
    const btn = document.createElement("button");
    btn.textContent = action.label;
    btn.addEventListener("click", () => {
      action.fn();
      elements.contextMenu.classList.add("hidden");
    });
    elements.contextMenu.appendChild(btn);
  }
  elements.contextMenu.style.left = `${x}px`;
  elements.contextMenu.style.top = `${y}px`;
  elements.contextMenu.classList.remove("hidden");
}

function closeContextMenu() {
  elements.contextMenu.classList.add("hidden");
}

function openGroupContextMenu(x, y, group) {
  elements.contextMenu.innerHTML = "";
  const actions = [
    { label: "重命名", fn: () => renameGroup(group) },
    { label: "删除分组", fn: () => deleteGroup(group) },
  ];
  for (const action of actions) {
    const btn = document.createElement("button");
    btn.textContent = action.label;
    btn.addEventListener("click", () => {
      action.fn();
      elements.contextMenu.classList.add("hidden");
    });
    elements.contextMenu.appendChild(btn);
  }
  elements.contextMenu.style.left = `${x}px`;
  elements.contextMenu.style.top = `${y}px`;
  elements.contextMenu.classList.remove("hidden");
}

function handleDropOnTile(targetId) {
  if (!dragState || dragState.id === targetId) return;
  if (activeGroupId === RECENT_GROUP_ID) return;
  const sourceId = dragState.id;
  const targetNode = data.nodes[targetId];
  const sourceNode = data.nodes[sourceId];
  if (!targetNode || !sourceNode) return;

  if (targetNode.type !== "folder") {
    pushBackup();
    const folderId = `fld_${Date.now()}`;
    const folder = {
      id: folderId,
      type: "folder",
      title: "新建文件夹",
      children: [targetId, sourceId],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    data.nodes[folderId] = folder;

    removeNodeFromLocation(sourceId);
    removeNodeFromLocation(targetId);

    const group = getActiveGroup();
    group.nodes.push(folderId);
    persistData();
    render();
    toast("已创建文件夹");
    return;
  }

  pushBackup();
  removeNodeFromLocation(sourceId);
  targetNode.children = targetNode.children || [];
  targetNode.children.push(sourceId);
  persistData();
  render();
  toast("已加入文件夹");
}

function dissolveFolder(folderId) {
  const folder = data.nodes[folderId];
  if (!folder || folder.type !== "folder") return;
  pushBackup();
  removeNodeFromLocation(folderId);
  const group = getActiveGroup();
  group.nodes.push(...(folder.children || []));
  delete data.nodes[folderId];
  persistData();
  render();
  toast("已解散文件夹");
}

function removeNodeFromLocation(id) {
  for (const group of data.groups) {
    group.nodes = group.nodes.filter((nid) => nid !== id);
  }
  for (const node of Object.values(data.nodes)) {
    if (node.type === "folder" && Array.isArray(node.children)) {
      node.children = node.children.filter((nid) => nid !== id);
    }
  }
}


function moveNodeInList(list, id, index) {
  const next = list.filter((nid) => nid !== id);
  const safeIndex = Math.max(0, Math.min(index, next.length));
  next.splice(safeIndex, 0, id);
  return next;
}

function dedupeData(input) {
  let changed = false;
  input.nodes = { ...(input.nodes || {}) };

  for (const group of input.groups || []) {
    const uniq = [];
    const set = new Set();
    for (const id of group.nodes || []) {
      if (!input.nodes[id]) {
        changed = true;
        continue;
      }
      if (set.has(id)) {
        changed = true;
        continue;
      }
      set.add(id);
      uniq.push(id);
    }
    group.nodes = uniq;
  }

  for (const node of Object.values(input.nodes)) {
    if (node.type === "folder" && Array.isArray(node.children)) {
      const uniq = [];
      const set = new Set();
      for (const id of node.children) {
        if (!input.nodes[id]) {
          changed = true;
          continue;
        }
        if (set.has(id)) {
          changed = true;
          continue;
        }
        set.add(id);
        uniq.push(id);
      }
      node.children = uniq;
    }
  }

  return changed;
}

function moveGroupBefore(sourceId, targetId) {
  const ids = data.groups.map((g) => g.id).filter((id) => id !== sourceId);
  const targetIndex = ids.indexOf(targetId);
  ids.splice(targetIndex, 0, sourceId);
  ids.forEach((id, idx) => {
    const group = data.groups.find((g) => g.id === id);
    if (group) group.order = idx;
  });
  persistData();
  render();
}

function renameGroup(group) {
  const name = prompt("分组名称", group.name);
  if (!name) return;
  group.name = name.trim();
  persistData();
  render();
}

function deleteGroup(group) {
  if (data.groups.length <= 1) {
    toast("至少保留一个分组");
    return;
  }
  if (!confirm(`删除分组「${group.name}」？`)) return;
  data.groups = data.groups.filter((g) => g.id !== group.id);
  if (activeGroupId === group.id) activeGroupId = data.groups[0].id;
  persistData();
  render();
}

function deleteNodes(ids) {
  if (!ids.length) return;
  if (activeGroupId === RECENT_GROUP_ID) return;
  pushBackup();
  const snapshot = JSON.parse(JSON.stringify(data));

  ids.forEach((id) => {
    removeNodeFromLocation(id);
    delete data.nodes[id];
  });

  pendingDeletion = { snapshot, ids };
  persistData();
  render();

  toast(`已删除 ${ids.length} 个快捷按钮`, "撤销", () => undoDelete());
  setTimeout(() => {
    pendingDeletion = null;
  }, 5000);
}

function undoDelete() {
  if (!pendingDeletion) return;
  data = pendingDeletion.snapshot;
  pendingDeletion = null;
  persistData();
  render();
  toast("已恢复");
}

function openModal(html) {
  elements.modal.innerHTML = html;
  elements.modalOverlay.classList.remove("hidden");
  elements.modalOverlay.setAttribute("aria-hidden", "false");
}

function closeModal() {
  elements.modalOverlay.classList.add("hidden");
  elements.modalOverlay.setAttribute("aria-hidden", "true");
  elements.modal.innerHTML = "";
  settingsOpen = false;
  settingsSaving = false;
}

function openAddModal() {
  const html = `
    <h2>新增快捷按钮</h2>
    <div class="section">
      <label>网址</label>
      <input id="fieldUrl" type="url" placeholder="https://" />
    </div>
    <div class="section">
      <label>标题</label>
      <input id="fieldTitle" type="text" placeholder="可选" />
    </div>
    <div class="section">
      <label>图标来源</label>
      <select id="fieldIconType">
        <option value="auto">自动抓取 favicon</option>
        <option value="upload">上传图标</option>
        <option value="color">颜色头像</option>
        <option value="remote">远程图标 URL</option>
      </select>
    </div>
    <div id="iconExtra" class="section"></div>
    <div class="section">
      <button id="btnFromTab" class="icon-btn">从当前标签页添加</button>
    </div>
    <div class="actions">
      <button id="btnCancel" class="icon-btn">取消</button>
      <button id="btnSave" class="icon-btn">保存</button>
    </div>
  `;
  openModal(html);

  const iconTypeEl = $("fieldIconType");
  const iconExtra = $("iconExtra");

  function renderIconExtra(type) {
    iconExtra.innerHTML = "";
    if (type === "upload") {
      iconExtra.innerHTML = `<label>上传图标</label><input id="fieldUpload" type="file" accept="image/*" />`;
    } else if (type === "color") {
      iconExtra.innerHTML = `<label>头像颜色</label><input id="fieldColor" type="color" value="#4dd6a8" />`;
    } else if (type === "remote") {
      iconExtra.innerHTML = `<label>远程图标 URL</label><input id="fieldRemote" type="url" placeholder="https://" />`;
    }
  }

  renderIconExtra(iconTypeEl.value);
  iconTypeEl.addEventListener("change", () => renderIconExtra(iconTypeEl.value));

  $("btnFromTab").addEventListener("click", async () => {
    const api = getChromeApi();
    if (!api?.tabs) return;
    api.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs?.[0];
      if (!tab) return;
      $("fieldUrl").value = tab.url || "";
      $("fieldTitle").value = tab.title || "";
    });
  });

  $("btnCancel").addEventListener("click", closeModal);
  $("btnSave").addEventListener("click", async () => {
    const snapshot = JSON.parse(JSON.stringify(data));
    const url = normalizeUrl($("fieldUrl").value.trim());
    if (!url) {
      toast("URL 不合法");
      return;
    }
    let title = $("fieldTitle").value.trim();
    const titlePending = !title;
    if (!title) title = new URL(url).hostname;
    let iconType = iconTypeEl.value;
    let iconData = "";
    let color = "";

    if (iconType === "upload") {
      const file = $("fieldUpload")?.files?.[0];
      if (file) {
        iconData = await readFileAsDataUrl(file);
      }
    } else if (iconType === "color") {
      color = $("fieldColor").value;
    } else if (iconType === "remote") {
      iconData = $("fieldRemote").value.trim();
    }

    const iconPending = iconType === "auto";
    if (iconType === "auto") {
      iconType = "letter";
    }

    pushBackup();
    const id = `itm_${Date.now()}`;
    data.nodes[id] = {
      id,
      type: "item",
      title,
      url,
      iconType,
      iconData,
      color,
      titlePending,
      iconPending,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    if (openFolderId) {
      data.nodes[openFolderId].children.push(id);
    } else {
      const targetGroup = getActiveGroup();
      targetGroup.nodes.push(id);
      if (activeGroupId === RECENT_GROUP_ID) {
        activeGroupId = targetGroup.id;
      }
    }
    data.settings.lastActiveGroupId = getActiveGroup().id;
    debugLog("add_item", {
      id,
      url,
      groupId: openFolderId ? openFolderId : getActiveGroup().id,
      openFolderId: openFolderId || "",
    });
    const result = await persistData();
    if (!result.ok) {
      data = snapshot;
      render();
      toast("保存失败：本地存储空间不足");
      return;
    }
    render();
    closeModal();
    if (titlePending) fetchTitleInBackground(id, url);
    if (iconPending) fetchFaviconInBackground(id, url);
    if (result.warning === "local_trimmed_backups") {
      toast("新增成功（已清理备份以释放空间）");
    } else if (result.warning === "local_trimmed_icons") {
      toast("新增成功（已重置上传图标以释放空间）");
    } else if (result.warning === "local_trimmed_background") {
      toast("新增成功（已清理自定义背景以释放空间）");
    } else if (result.warning === "sync_quota_exceeded") {
      toast("新增成功（同步空间不足，已保存到本地）");
    } else {
      toast("新增成功");
    }
  });
}

function openEditModal(node) {
  const html = `
    <h2>编辑</h2>
    <div class="section">
      <label>标题</label>
      <input id="fieldTitle" type="text" value="${node.title || ""}" />
    </div>
    ${node.type === "item" ? `
    <div class="section">
      <label>网址</label>
      <input id="fieldUrl" type="url" value="${node.url || ""}" />
    </div>
    <div class="section">
      <label>图标来源</label>
      <select id="fieldIconType">
        <option value="auto">自动抓取 favicon</option>
        <option value="upload">上传图标</option>
        <option value="color">颜色头像</option>
        <option value="remote">远程图标 URL</option>
      </select>
    </div>
    <div id="iconExtra" class="section"></div>
    ` : ""}
    <div class="actions">
      <button id="btnCancel" class="icon-btn">取消</button>
      <button id="btnSave" class="icon-btn">保存</button>
    </div>
  `;
  openModal(html);

  if (node.type === "item") {
    const iconTypeEl = $("fieldIconType");
    iconTypeEl.value = node.iconType === "letter" ? "auto" : (node.iconType || "auto");
    const iconExtra = $("iconExtra");
    function renderIconExtra(type) {
      iconExtra.innerHTML = "";
      if (type === "upload") {
        iconExtra.innerHTML = `<label>上传图标</label><input id="fieldUpload" type="file" accept="image/*" />`;
      } else if (type === "color") {
        iconExtra.innerHTML = `<label>头像颜色</label><input id="fieldColor" type="color" value="${node.color || "#4dd6a8"}" />`;
      } else if (type === "remote") {
        iconExtra.innerHTML = `<label>远程图标 URL</label><input id="fieldRemote" type="url" value="${node.iconData || ""}" />`;
      }
    }
    renderIconExtra(iconTypeEl.value);
    iconTypeEl.addEventListener("change", () => renderIconExtra(iconTypeEl.value));
  }

  $("btnCancel").addEventListener("click", closeModal);
  $("btnSave").addEventListener("click", async () => {
    const snapshot = JSON.parse(JSON.stringify(data));
    pushBackup();
    node.title = $("fieldTitle").value.trim() || node.title;
    if (node.type === "item") {
      const url = normalizeUrl($("fieldUrl").value.trim());
      if (!url) {
        toast("URL 不合法");
        return;
      }
      node.url = url;
      const iconType = $("fieldIconType").value;
      node.iconType = iconType;
      if (iconType === "upload") {
        const file = $("fieldUpload")?.files?.[0];
        if (file) node.iconData = await readFileAsDataUrl(file);
      } else if (iconType === "color") {
        node.color = $("fieldColor").value;
        node.iconData = "";
      } else if (iconType === "remote") {
        node.iconData = $("fieldRemote").value.trim();
      } else {
        node.iconData = "";
      }
    }
    node.updatedAt = Date.now();
    const result = await persistData();
    if (!result.ok) {
      data = snapshot;
      render();
      toast("保存失败：本地存储空间不足");
      return;
    }
    render();
    closeModal();
    if (result.warning === "local_trimmed_backups") {
      toast("保存成功（已清理备份以释放空间）");
    } else if (result.warning === "local_trimmed_icons") {
      toast("保存成功（已重置上传图标以释放空间）");
    } else if (result.warning === "local_trimmed_background") {
      toast("保存成功（已清理自定义背景以释放空间）");
    } else if (result.warning === "sync_quota_exceeded") {
      toast("保存成功（同步空间不足，已保存到本地）");
    } else {
      toast("保存成功");
    }
  });
}

function openOpenModeMenu() {
  const modes = [
    { id: "current", label: "当前标签打开" },
    { id: "new", label: "新标签打开" },
    { id: "background", label: "后台新标签打开" },
  ];
  const idx = modes.findIndex((m) => m.id === data.settings.openMode);
  const next = modes[(idx + 1) % modes.length];
  data.settings.openMode = next.id;
  persistData();
  updateOpenModeButton();
  toast(`${next.label}`);
}

function openSettingsModal() {
  settingsOpen = true;
  const groupsHtml = data.groups
    .sort((a, b) => a.order - b.order)
    .map(
      (g) => `
      <div class="row" data-group="${g.id}">
        <input type="text" value="${g.name}" class="group-name" />
        <div style="display:flex; gap:8px; justify-content:flex-end;">
          <button class="icon-btn group-up">上移</button>
          <button class="icon-btn group-down">下移</button>
          <button class="icon-btn group-del">删除</button>
        </div>
      </div>`
    )
    .join("");

  const html = `
    <h2>设置</h2>
    <div class="section">
      <label><input id="settingShowSearch" type="checkbox"> 显示顶部搜索框</label>
      <label><input id="settingEnableSearchEngine" type="checkbox"> 回车使用默认搜索引擎</label>
      <label>默认搜索引擎 URL</label>
      <div class="row">
        <select id="settingSearchEnginePreset">
          <option value="https://www.google.com/search?q=">Google</option>
          <option value="https://www.baidu.com/s?wd=">百度</option>
          <option value="https://www.bing.com/search?q=">Bing</option>
          <option value="https://www.so.com/s?q=">360</option>
          <option value="https://www.yandex.com/search/?text=">Yandex</option>
          <option value="custom">自定义</option>
        </select>
        <input id="settingSearchEngine" type="text" placeholder="https://www.bing.com/search?q=" />
      </div>
    </div>

    <div class="section">
      <label>打开方式</label>
      <select id="settingOpenMode">
        <option value="current">当前标签打开</option>
        <option value="new">新标签打开</option>
        <option value="background">后台新标签打开</option>
      </select>
    </div>

    <div class="section">
      <label><input id="settingFixedLayout" type="checkbox"> 固定布局</label>
      <div class="row">
        <div>
          <label>行数</label>
          <input id="settingRows" type="number" min="1" />
        </div>
        <div>
          <label>列数</label>
          <input id="settingCols" type="number" min="1" />
        </div>
      </div>
      <label>网格密度</label>
      <div class="row">
        <label><input type="radio" name="density" value="compact" /> 紧凑</label>
        <label><input type="radio" name="density" value="standard" /> 标准</label>
        <label><input type="radio" name="density" value="spacious" /> 宽松</label>
      </div>
    </div>

    <div class="section">
      <label>背景</label>
      <select id="settingBgType">
        <option value="bing">每日 Bing</option>
        <option value="color">纯色</option>
        <option value="gradient">渐变</option>
        <option value="custom">自定义图片</option>
      </select>
      <div id="bgColorWrap">
        <label>背景颜色</label>
        <input id="settingBgColor" type="color" />
      </div>
      <div id="bgGradientWrap">
        <label>渐变颜色</label>
        <div class="row">
          <input id="settingBgGradientA" type="color" />
          <input id="settingBgGradientB" type="color" />
        </div>
      </div>
      <input id="settingBgGradient" type="hidden" />
      <label>自定义图片</label>
      <input id="settingBgFile" type="file" accept="image/*" />
    </div>

    <div class="section">
      <label><input id="settingTooltip" type="checkbox"> 启用 Tooltip</label>
      <label><input id="settingKeyboard" type="checkbox"> 启用键盘导航</label>
    </div>

    <div class="section">
      <label>主题颜色</label>
      <select id="settingTheme">
        <option value="system">跟随系统</option>
        <option value="light">浅色</option>
        <option value="dark">深色</option>
      </select>
    </div>

    <div class="section">
      <label>字体大小</label>
      <input id="settingFontSize" type="number" min="10" max="24" />
    </div>

    <div class="section">
      <label>默认保存分组</label>
      <select id="settingDefaultGroupMode">
        <option value="last">上次添加的分组</option>
        <option value="fixed">固定分组</option>
      </select>
      <select id="settingDefaultGroupId"></select>
    </div>

    <div class="section">
      <label><input id="settingSidebarCollapsed" type="checkbox"> 收起左侧分组</label>
      <button id="btnToggleSidebarSetting" class="icon-btn">收起/展开</button>
    </div>

    <div class="section">
      <label><input id="settingSync" type="checkbox"> 启用同步</label>
      <label>最大备份数量（0 表示不备份）</label>
      <input id="settingBackup" type="number" min="0" />
      <label><input id="settingIconRetry" type="checkbox"> 18:00 自动重试图标</label>
    </div>

    <div class="section">
      <label>分组管理</label>
      <div id="groupList">${groupsHtml}</div>
      <button id="btnAddGroup" class="icon-btn">新增分组</button>
    </div>

    <div class="section">
      <button id="btnExport" class="icon-btn">导出 JSON</button>
      <button id="btnImport" class="icon-btn">导入 JSON</button>
      <button id="btnBackupManage" class="icon-btn">备份管理</button>
      <button id="btnClearData" class="icon-btn danger">清空数据</button>
      <button id="btnRefreshIcons" class="icon-btn">刷新所有图标</button>
    </div>

    <div class="actions">
      <button id="btnCancel" class="icon-btn">关闭</button>
      <button id="btnSave" class="icon-btn">保存设置</button>
    </div>
  `;
  openModal(html);

  $("settingShowSearch").checked = data.settings.showSearch;
  $("settingEnableSearchEngine").checked = data.settings.enableSearchEngine;
  $("settingSearchEngine").value = data.settings.searchEngineUrl;
  const presets = {
    "https://www.google.com/search?q=": "https://www.google.com/search?q=",
    "https://www.baidu.com/s?wd=": "https://www.baidu.com/s?wd=",
    "https://www.bing.com/search?q=": "https://www.bing.com/search?q=",
    "https://www.so.com/s?q=": "https://www.so.com/s?q=",
    "https://www.yandex.com/search/?text=": "https://www.yandex.com/search/?text=",
  };
  const presetValue = presets[data.settings.searchEngineUrl] || "custom";
  $("settingSearchEnginePreset").value = presetValue;
  $("settingSearchEngine").disabled = presetValue !== "custom";
  $("settingOpenMode").value = data.settings.openMode;
  $("settingFixedLayout").checked = data.settings.fixedLayout;
  $("settingRows").value = data.settings.fixedRows;
  $("settingCols").value = data.settings.fixedCols;
  const densityRadios = qsa("input[name='density']", elements.modal);
  densityRadios.forEach((radio) => {
    radio.checked = radio.value === data.settings.gridDensity;
  });
  $("settingBgType").value = data.settings.backgroundType;
  $("settingBgColor").value = data.settings.backgroundColor;
  $("settingBgGradient").value = data.settings.backgroundGradient;
  const match = /linear-gradient\\([^,]+,\\s*([^,]+),\\s*([^\\)]+)\\)/.exec(data.settings.backgroundGradient || "");
  $("settingBgGradientA").value = match?.[1]?.trim() || "#1d2a3b";
  $("settingBgGradientB").value = match?.[2]?.trim() || "#0b0f14";
  $("settingTooltip").checked = data.settings.tooltipEnabled;
  $("settingKeyboard").checked = data.settings.keyboardNav;
  $("settingTheme").value = data.settings.theme || "system";
  $("settingFontSize").value = data.settings.fontSize || 13;
  $("settingSync").checked = data.settings.syncEnabled;
  $("settingBackup").value = data.settings.maxBackups;
  $("settingIconRetry").checked = data.settings.iconRetryAtSix;
  $("settingSidebarCollapsed").checked = data.settings.sidebarCollapsed;

  const defaultGroupMode = $("settingDefaultGroupMode");
  const defaultGroupId = $("settingDefaultGroupId");
  defaultGroupMode.value = data.settings.defaultGroupMode || "last";
  defaultGroupId.innerHTML = "";
  data.groups
    .sort((a, b) => a.order - b.order)
    .forEach((g) => {
      const opt = document.createElement("option");
      opt.value = g.id;
      opt.textContent = g.name;
      defaultGroupId.appendChild(opt);
    });
  if (data.settings.defaultGroupId) defaultGroupId.value = data.settings.defaultGroupId;

  $("btnAddGroup").addEventListener("click", () => {
    const groupId = `grp_${Date.now()}`;
    data.groups.push({ id: groupId, name: "新分组", order: data.groups.length, nodes: [] });
    openSettingsModal();
  });

  $("btnToggleSidebarSetting").addEventListener("click", () => {
    data.settings.sidebarCollapsed = !data.settings.sidebarCollapsed;
    $("settingSidebarCollapsed").checked = data.settings.sidebarCollapsed;
    applySidebarState();
  });

  $("settingSearchEnginePreset").addEventListener("change", (e) => {
    const val = e.target.value;
    if (val === "custom") {
      $("settingSearchEngine").disabled = false;
      $("settingSearchEngine").focus();
    } else {
      $("settingSearchEngine").value = val;
      $("settingSearchEngine").disabled = true;
    }
  });

  qsa(".group-up", elements.modal).forEach((btn) => {
    btn.addEventListener("click", () => {
      const row = btn.closest("[data-group]");
      const id = row.dataset.group;
      const idx = data.groups.findIndex((g) => g.id === id);
      if (idx > 0) {
        const tmp = data.groups[idx - 1];
        data.groups[idx - 1] = data.groups[idx];
        data.groups[idx] = tmp;
        openSettingsModal();
      }
    });
  });

  qsa(".group-down", elements.modal).forEach((btn) => {
    btn.addEventListener("click", () => {
      const row = btn.closest("[data-group]");
      const id = row.dataset.group;
      const idx = data.groups.findIndex((g) => g.id === id);
      if (idx >= 0 && idx < data.groups.length - 1) {
        const tmp = data.groups[idx + 1];
        data.groups[idx + 1] = data.groups[idx];
        data.groups[idx] = tmp;
        openSettingsModal();
      }
    });
  });

  qsa(".group-del", elements.modal).forEach((btn) => {
    btn.addEventListener("click", () => {
      const row = btn.closest("[data-group]");
      const id = row.dataset.group;
      if (data.groups.length <= 1) {
        toast("至少保留一个分组");
        return;
      }
      data.groups = data.groups.filter((g) => g.id !== id);
      if (activeGroupId === id) activeGroupId = data.groups[0].id;
      openSettingsModal();
    });
  });

  $("btnExport").addEventListener("click", () => openExportModal());
  $("btnImport").addEventListener("click", () => openImportModal());
  $("btnBackupManage").addEventListener("click", () => openBackupModal());
  $("btnClearData").addEventListener("click", async () => {
    if (!confirm("确认清空全部数据？")) return;
    data = defaultData();
    activeGroupId = data.groups[0].id;
    await clearData(data.settings.syncEnabled);
    await persistData();
    closeModal();
    render();
    toast("已清空");
  });
  $("btnRefreshIcons").addEventListener("click", async () => {
    await refreshAllIcons(Object.values(data.nodes));
    toast("图标刷新完成");
  });

  const saveSettings = async () => {
    if (settingsSaving) return;
    settingsSaving = true;
    qsa(".group-name", elements.modal).forEach((input) => {
      const row = input.closest("[data-group]");
      const id = row.dataset.group;
      const group = data.groups.find((g) => g.id === id);
      if (group) group.name = input.value.trim() || group.name;
    });

    data.settings.showSearch = $("settingShowSearch").checked;
    data.settings.enableSearchEngine = $("settingEnableSearchEngine").checked;
    data.settings.searchEngineUrl = $("settingSearchEngine").value.trim() || data.settings.searchEngineUrl;
    data.settings.openMode = $("settingOpenMode").value;
    data.settings.fixedLayout = $("settingFixedLayout").checked;
    data.settings.fixedRows = Number($("settingRows").value) || 3;
    data.settings.fixedCols = Number($("settingCols").value) || 8;
    const selectedDensity = qsa("input[name='density']", elements.modal).find((r) => r.checked);
    data.settings.gridDensity = selectedDensity ? selectedDensity.value : data.settings.gridDensity;
    data.settings.backgroundType = $("settingBgType").value;
    data.settings.backgroundColor = $("settingBgColor").value;
    const gA = $("settingBgGradientA").value || "#1d2a3b";
    const gB = $("settingBgGradientB").value || "#0b0f14";
    data.settings.backgroundGradient = `linear-gradient(120deg, ${gA}, ${gB})`;
    data.settings.tooltipEnabled = $("settingTooltip").checked;
    data.settings.keyboardNav = $("settingKeyboard").checked;
    data.settings.fontSize = Number($("settingFontSize").value) || data.settings.fontSize;
    data.settings.theme = $("settingTheme").value;
    data.settings.defaultGroupMode = $("settingDefaultGroupMode").value;
    data.settings.defaultGroupId = $("settingDefaultGroupId").value;
    data.settings.sidebarCollapsed = $("settingSidebarCollapsed").checked;
    data.settings.syncEnabled = $("settingSync").checked;
    data.settings.maxBackups = Number($("settingBackup").value) || 0;
    data.settings.iconRetryAtSix = $("settingIconRetry").checked;

    const bgFile = $("settingBgFile").files?.[0];
    if (bgFile) {
      data.settings.backgroundCustom = await readFileAsDataUrl(bgFile);
    }

    applyDensity();
    applyTheme();
    await persistData();
    await loadBackground();
    closeModal();
    render();
    toast("设置已保存");
  };

  $("btnCancel").addEventListener("click", closeModal);
  $("btnSave").addEventListener("click", saveSettings);

  const updateBgControls = () => {
    const type = $("settingBgType").value;
    $("bgColorWrap").classList.toggle("hidden", type === "bing" || type === "gradient");
    $("bgGradientWrap").classList.toggle("hidden", type !== "gradient");
  };
  $("settingBgType").addEventListener("change", updateBgControls);
  updateBgControls();
}

function openExportModal() {
  const payload = JSON.stringify(data, null, 2);
  const html = `
    <h2>导出 JSON</h2>
    <div class="section">
      <textarea readonly>${payload}</textarea>
    </div>
    <div class="actions">
      <button id="btnCopy" class="icon-btn">复制</button>
      <button id="btnClose" class="icon-btn">关闭</button>
    </div>
  `;
  openModal(html);
  $("btnCopy").addEventListener("click", async () => {
    await navigator.clipboard.writeText(payload);
    toast("已复制");
  });
  $("btnClose").addEventListener("click", closeModal);
}

function openImportModal() {
  const html = `
    <h2>导入 JSON</h2>
    <div class="section">
      <label>导入策略</label>
      <select id="importMode">
        <option value="replace">覆盖所有</option>
        <option value="merge">合并现有</option>
        <option value="add">仅新增不覆盖</option>
      </select>
    </div>
    <div class="section">
      <textarea id="importText" placeholder="粘贴 JSON"></textarea>
    </div>
    <div class="actions">
      <button id="btnCancel" class="icon-btn">取消</button>
      <button id="btnImportNow" class="icon-btn">导入</button>
    </div>
  `;
  openModal(html);
  $("btnCancel").addEventListener("click", closeModal);
  $("btnImportNow").addEventListener("click", async () => {
    try {
      const incoming = JSON.parse($("importText").value.trim());
      const mode = $("importMode").value;
      if (!incoming.schemaVersion) throw new Error("无 schemaVersion");
      pushBackup();
      if (mode === "replace") {
        data = incoming;
      } else if (mode === "merge") {
        data.groups = [...data.groups, ...incoming.groups];
        data.nodes = { ...data.nodes, ...incoming.nodes };
      } else if (mode === "add") {
        for (const [id, node] of Object.entries(incoming.nodes || {})) {
          if (!data.nodes[id]) data.nodes[id] = node;
        }
        data.groups = [...data.groups, ...incoming.groups.filter((g) => !data.groups.find((x) => x.id === g.id))];
      }
      await persistData();
      closeModal();
      render();
      toast("导入成功");
    } catch (err) {
      toast(`导入失败：${err.message}`);
    }
  });
}

function openBackupModal() {
  const list = data.backups
    .map((b) => `<div class="row" data-backup="${b.id}"><div>${new Date(b.ts).toLocaleString()}</div><button class="icon-btn backup-restore">恢复</button></div>`)
    .join("");
  const html = `
    <h2>备份管理</h2>
    <div class="section">${list || "暂无备份"}</div>
    <div class="actions"><button id="btnClose" class="icon-btn">关闭</button></div>
  `;
  openModal(html);
  qsa(".backup-restore", elements.modal).forEach((btn) => {
    btn.addEventListener("click", () => {
      const row = btn.closest("[data-backup]");
      const backup = data.backups.find((b) => b.id === row.dataset.backup);
      if (!backup) return;
      data = backup.data;
      persistData();
      closeModal();
      render();
      toast("已恢复备份");
    });
  });
  $("btnClose").addEventListener("click", closeModal);
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function probeImage(url, timeoutMs = 6000) {
  return new Promise((resolve) => {
    let done = false;
    const img = new Image();
    const timer = setTimeout(() => finish(false), timeoutMs);
    const finish = (ok) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      img.onload = null;
      img.onerror = null;
      resolve(ok);
    };
    img.onload = () => finish(true);
    img.onerror = () => finish(false);
    img.src = url;
  });
}

async function fetchTitleInBackground(nodeId, url) {
  const title = await fetchTitleViaTab(url);
  if (!title) return;
  const target = data?.nodes?.[nodeId];
  if (!target || !target.titlePending) return;
  target.title = title;
  target.titlePending = false;
  await persistData();
  render();
}

async function fetchFaviconInBackground(nodeId, url) {
  if (!data?.settings?.iconFetch) return;
  const candidates = getFaviconCandidates(url);
  if (!candidates.length) return;
  const cache = await loadIconCache();
  const siteKey = getSiteKey(url);
  for (const candidate of candidates) {
    const ok = await probeImage(candidate);
    if (!ok) continue;
    cache[url] = { url: candidate, ts: Date.now() };
    if (siteKey) cache[siteKey] = { url: candidate, ts: Date.now() };
    await saveIconCache(cache);
    const target = data?.nodes?.[nodeId];
    if (target) target.iconPending = false;
    await persistData();
    render();
    return;
  }
  const target = data?.nodes?.[nodeId];
  if (target) {
    target.iconPending = false;
    await persistData();
    render();
  }
}

async function fetchTitleViaTab(url) {
  const api = getChromeApi();
  if (!api?.tabs) return "";
  return new Promise((resolve) => {
    api.tabs.create({ url, active: false }, (tab) => {
      if (!tab?.id) return resolve("");
      const tabId = tab.id;
      const timeout = setTimeout(() => finish(""), 6000);
      const finish = (title) => {
        clearTimeout(timeout);
        api.tabs.onUpdated.removeListener(onUpdated);
        api.tabs.remove(tabId, () => resolve(title || ""));
      };
      const onUpdated = (id, info, updatedTab) => {
        if (id === tabId && info.status === "complete") {
          finish(updatedTab?.title || "");
        }
      };
      api.tabs.onUpdated.addListener(onUpdated);
    });
  });
}

async function loadRecentHistory() {
  const api = getChromeApi();
  if (!api?.history?.search) return [];
  const startTime = Date.now() - 7 * 24 * 60 * 60 * 1000;
  try {
    const result = api.history.search({ text: "", startTime, maxResults: RECENT_LIMIT });
    const items = typeof result?.then === "function" ? await result : await new Promise((resolve) => {
      api.history.search({ text: "", startTime, maxResults: RECENT_LIMIT }, (res) => resolve(res || []));
    });
    const seen = new Set();
    return (items || [])
      .filter((item) => item.url)
      .filter((item) => {
        let norm = item.url;
        try { norm = new URL(item.url).href; } catch {}
        if (seen.has(norm)) return false;
        seen.add(norm);
        return true;
      })
      .map((item, idx) => ({
        id: `recent_${idx}`,
        type: "history",
        title: item.title || item.url,
        url: item.url,
      }));
  } catch (err) {
    return [];
  }
}

async function addHistoryToShortcuts(node) {
  if (!node?.url) return;
  pushBackup();
  const id = `itm_${Date.now()}`;
  data.nodes[id] = {
    id,
    type: "item",
    title: node.title || new URL(node.url).hostname,
    url: node.url,
    iconType: "auto",
    iconData: "",
    color: "",
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  getActiveGroup().nodes.push(id);
  await persistData();
  render();
  toast("已添加到快捷");
}

function handleSearchInput() {
  const query = elements.topSearch.value.trim().toLowerCase();
  if (!query) {
    render();
    return;
  }
  const grid = openFolderId ? elements.folderGrid : elements.grid;
  qsa(".tile", grid).forEach((tile) => {
    const node = data.nodes[tile.dataset.id];
    const text = `${node.title || ""} ${node.url || ""}`.toLowerCase();
    tile.style.display = text.includes(query) ? "" : "none";
  });
}

function ensureSelectionBox() {
  if (!selectionBox) {
    selectionBox = document.createElement("div");
    selectionBox.className = "selection-box hidden";
    document.body.appendChild(selectionBox);
  }
}

function updateSelectionBox(x1, y1, x2, y2) {
  const left = Math.min(x1, x2);
  const top = Math.min(y1, y2);
  const width = Math.abs(x1 - x2);
  const height = Math.abs(y1 - y2);
  selectionBox.style.left = `${left}px`;
  selectionBox.style.top = `${top}px`;
  selectionBox.style.width = `${width}px`;
  selectionBox.style.height = `${height}px`;
  selectionBox.classList.remove("hidden");
}

function selectTilesInBox(grid, x1, y1, x2, y2) {
  const left = Math.min(x1, x2);
  const right = Math.max(x1, x2);
  const top = Math.min(y1, y2);
  const bottom = Math.max(y1, y2);
  qsa(".tile", grid).forEach((tile) => {
    const rect = tile.getBoundingClientRect();
    const hit = rect.left < right && rect.right > left && rect.top < bottom && rect.bottom > top;
    if (hit) selectedIds.add(tile.dataset.id);
  });
}

function getDropIndex(grid, x, y) {
  const tiles = qsa(".tile", grid);
  for (let i = 0; i < tiles.length; i++) {
    const rect = tiles[i].getBoundingClientRect();
    if (y < rect.top + rect.height / 2) return i;
  }
  return tiles.length;
}

async function init() {
  debugLog("init_start", getRuntimeInfo());
  const localData = await loadData();
  debugLog("init_local", {
    groups: localData.groups?.length || 0,
    nodes: Object.keys(localData.nodes || {}).length,
    lastUpdated: localData.lastUpdated || 0,
    syncEnabled: !!localData.settings?.syncEnabled,
  });
  if (localData.settings.syncEnabled) {
    const syncData = await loadDataFromArea(true);
    if (syncData && syncData.groups?.length) {
      const localTs = Number(localData.lastUpdated || 0);
      const syncTs = Number(syncData.lastUpdated || 0);
      data = syncTs >= localTs ? syncData : localData;
      if (data === localData) {
        await saveData(localData, true);
      }
    } else {
      data = localData;
    }
  } else {
    data = localData;
  }
  const deduped = dedupeData(data);
  if (deduped) {
    await saveData(data, data.settings.syncEnabled);
    if (data.settings.syncEnabled) await saveData(data, false);
  }
  debugLog("init_ready", {
    groups: data.groups?.length || 0,
    nodes: Object.keys(data.nodes || {}).length,
    lastUpdated: data.lastUpdated || 0,
    deduped,
    activeGroupId,
  });
  const preferredGroupId = data.settings.lastActiveGroupId;
  if (preferredGroupId === RECENT_GROUP_ID) {
    activeGroupId = RECENT_GROUP_ID;
  } else if (preferredGroupId && data.groups.find((g) => g.id === preferredGroupId)) {
    activeGroupId = preferredGroupId;
  } else {
    activeGroupId = data.groups?.[0]?.id || RECENT_GROUP_ID;
    data.settings.lastActiveGroupId = activeGroupId;
  }
  recentItems = await loadRecentHistory();
  applyDensity();
  applyTheme();
  applySidebarState();
  closeModal();
  closeFolder();
  await loadBackground();
  await retryFailedIconsIfDue(data.settings);
  render();
}

function render() {
  renderGroups();
  renderGrid();
  elements.topSearchWrap.classList.toggle("hidden", !data.settings.showSearch);
  elements.emptyHintToggle.checked = data.settings.emptyHintDisabled;
  elements.btnSelectAll.classList.toggle("hidden", !selectionMode);
  elements.btnBatchDelete.textContent = selectionMode ? "删除" : "批量删除";
  updateOpenModeButton();
}

function updateOpenModeButton() {
  const map = {
    current: "当前标签打开",
    new: "新标签打开",
    background: "后台新标签打开",
  };
  const label = map[data.settings.openMode] || "当前标签打开";
  elements.btnOpenMode.textContent = `${label}`;
}

function bindEvents() {
  window.addEventListener("resize", () => render());

  elements.btnAdd.addEventListener("click", openAddModal);
  elements.btnFolderAdd.addEventListener("click", openAddModal);
  elements.btnToggleSidebar?.addEventListener("click", () => {
    data.settings.sidebarCollapsed = !data.settings.sidebarCollapsed;
    applySidebarState();
    persistData();
  });
  elements.recentTab.addEventListener("click", async () => {
    activeGroupId = RECENT_GROUP_ID;
    openFolderId = null;
    data.settings.lastActiveGroupId = activeGroupId;
    persistData();
    recentItems = await loadRecentHistory();
    render();
  });
  elements.btnAddGroup.addEventListener("click", () => {
    const groupId = `grp_${Date.now()}`;
    data.groups.push({ id: groupId, name: "新分组", order: data.groups.length, nodes: [] });
    activeGroupId = groupId;
    data.settings.lastActiveGroupId = activeGroupId;
    persistData();
    render();
  });

  elements.btnBatchDelete.addEventListener("click", () => {
    if (activeGroupId === RECENT_GROUP_ID) {
      toast("最近浏览不可批量删除");
      return;
    }
    if (!selectionMode) {
      selectionMode = true;
      toast("进入批量选择模式");
      render();
      return;
    }
    const ids = Array.from(selectedIds);
    if (!ids.length) {
      clearSelection();
      render();
      return;
    }
    deleteNodes(ids);
    clearSelection();
    render();
  });

  elements.btnFolderBatchDelete.addEventListener("click", () => {
    if (activeGroupId === RECENT_GROUP_ID) {
      toast("最近浏览不可批量删除");
      return;
    }
    if (!selectionMode) {
      selectionMode = true;
      toast("进入批量选择模式");
      render();
      return;
    }
    const ids = Array.from(selectedIds);
    if (!ids.length) {
      clearSelection();
      render();
      return;
    }
    deleteNodes(ids);
    clearSelection();
    render();
  });

  elements.btnSelectAll.addEventListener("click", () => {
    if (!selectionMode) return;
    const grid = openFolderId ? elements.folderGrid : elements.grid;
    qsa(".tile", grid).forEach((tile) => selectedIds.add(tile.dataset.id));
    render();
  });

  elements.main?.addEventListener?.("click", (e) => {
    if (suppressBlankClick) {
      suppressBlankClick = false;
      return;
    }
    if (!selectionMode || boxSelecting) return;
    if (e.target.closest(".tile")) return;
    clearSelection();
    render();
  });

  elements.btnOpenMode.addEventListener("click", openOpenModeMenu);
  elements.btnSettings.addEventListener("click", openSettingsModal);
  elements.btnSearch.addEventListener("click", () => {
    const query = elements.topSearch.value.trim();
    if (!query) {
      elements.topSearch.focus();
      return;
    }
    openUrl(`${data.settings.searchEngineUrl}${encodeURIComponent(query)}`, "new");
  });

  elements.topSearch.addEventListener("input", handleSearchInput);
  elements.topSearch.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && data.settings.enableSearchEngine) {
      const query = elements.topSearch.value.trim();
      if (!query) return;
      openUrl(`${data.settings.searchEngineUrl}${encodeURIComponent(query)}`, "new");
    }
  });

  elements.topSearch.addEventListener("focus", async () => {
    if (activeGroupId === RECENT_GROUP_ID) {
      recentItems = await loadRecentHistory();
      render();
    }
  });

  elements.emptyHintToggle.addEventListener("change", async (e) => {
    data.settings.emptyHintDisabled = e.target.checked;
    await persistData();
    render();
  });

  elements.btnCloseFolder.addEventListener("click", closeFolder);

  elements.modalOverlay.addEventListener("click", (e) => {
    if (e.target !== elements.modalOverlay) return;
    if (settingsOpen) {
      const btn = $("btnSave");
      if (btn) btn.click();
      return;
    }
    closeModal();
  });

  const handleBoxSelectStart = (e, grid) => {
    if (e.button !== 0) return;
    if (e.target.closest(".tile")) return;
    if (!selectionMode) return;
    boxSelecting = true;
    isDraggingBox = false;
    ensureSelectionBox();
    selectionStart = { x: e.clientX, y: e.clientY, grid };
    updateSelectionBox(e.clientX, e.clientY, e.clientX, e.clientY);
  };

  const handleBoxSelectMove = (e) => {
    if (!boxSelecting || !selectionStart) return;
    const dx = Math.abs(e.clientX - selectionStart.x);
    const dy = Math.abs(e.clientY - selectionStart.y);
    if (dx + dy > 6) isDraggingBox = true;
    updateSelectionBox(selectionStart.x, selectionStart.y, e.clientX, e.clientY);
  };

  const handleBoxSelectEnd = (e) => {
    if (!boxSelecting || !selectionStart) return;
    if (isDraggingBox) {
      selectTilesInBox(selectionStart.grid, selectionStart.x, selectionStart.y, e.clientX, e.clientY);
      suppressBlankClick = true;
    }
    boxSelecting = false;
    selectionStart = null;
    isDraggingBox = false;
    if (selectionBox) selectionBox.classList.add("hidden");
    render();
  };

  elements.grid.addEventListener("mousedown", (e) => handleBoxSelectStart(e, elements.grid));
  elements.folderGrid.addEventListener("mousedown", (e) => handleBoxSelectStart(e, elements.folderGrid));
  elements.main?.addEventListener?.("mousedown", (e) => {
    if (openFolderId) return;
    handleBoxSelectStart(e, elements.grid);
  });
  document.addEventListener("mousemove", handleBoxSelectMove);
  document.addEventListener("mouseup", handleBoxSelectEnd);

  document.addEventListener("click", (e) => {
    if (!elements.contextMenu.contains(e.target)) closeContextMenu();
  });

  document.addEventListener("mousemove", (e) => {
    if (!elements.tooltip.classList.contains("hidden")) {
      elements.tooltip.style.left = `${e.clientX + 12}px`;
      elements.tooltip.style.top = `${e.clientY + 12}px`;
    }
  });

  document.addEventListener("mouseover", (e) => {
    const target = e.target.closest("[data-tooltip]");
    if (!target) return;
    const text = target.getAttribute("data-tooltip");
    if (text) showTooltip(text, e.clientX, e.clientY);
  });

  document.addEventListener("mouseout", (e) => {
    const target = e.target.closest("[data-tooltip]");
    if (!target) return;
    hideTooltip();
  });

  document.addEventListener("keydown", (e) => {
    if (!data.settings.keyboardNav) return;
    if (e.key === "Escape" && openFolderId) closeFolder();
    if (e.key === "/") {
      elements.topSearch.focus();
      e.preventDefault();
    }
  });

  elements.grid.addEventListener("dragover", (e) => e.preventDefault());
  elements.grid.addEventListener("drop", (e) => {
    e.preventDefault();
    if (!dragState) return;
    if (activeGroupId === RECENT_GROUP_ID) return;
    const sourceId = dragState.id;
    if (openFolderId) return;
    const group = getActiveGroup();
    const index = getDropIndex(elements.grid, e.clientX, e.clientY);
    group.nodes = moveNodeInList(group.nodes, sourceId, index);
    persistData();
    render();
  });

  elements.folderGrid.addEventListener("dragover", (e) => e.preventDefault());
  elements.folderGrid.addEventListener("drop", (e) => {
    e.preventDefault();
    if (!dragState || !openFolderId) return;
    const sourceId = dragState.id;
    const folder = data.nodes[openFolderId];
    const index = getDropIndex(elements.folderGrid, e.clientX, e.clientY);
    folder.children = moveNodeInList(folder.children || [], sourceId, index);
    persistData();
    render();
  });
}

init();
bindEvents();
